create procedure proc_get_column_demo(INOUT pColumn varchar(100))
BEGIN
     declare tempstr VARCHAR(100);
     SELECT 
	goodsName 
     FROM
	aliyun.Goods_Table
     WHERE goodsName = pColumn
     INTO tempstr;
     set pColumn=tempstr;
     SELECT @pColumn;
END;

