create view test_view_1 as (select `information_schema`.`Columns`.`TABLE_CATALOG`            AS `TABLE_CATALOG`,
                                   `information_schema`.`Columns`.`TABLE_SCHEMA`             AS `TABLE_SCHEMA`,
                                   `information_schema`.`Columns`.`TABLE_NAME`               AS `TABLE_NAME`,
                                   `information_schema`.`Columns`.`COLUMN_NAME`              AS `COLUMN_NAME`,
                                   `information_schema`.`Columns`.`ORDINAL_POSITION`         AS `ORDINAL_POSITION`,
                                   `information_schema`.`Columns`.`COLUMN_DEFAULT`           AS `COLUMN_DEFAULT`,
                                   `information_schema`.`Columns`.`IS_NULLABLE`              AS `IS_NULLABLE`,
                                   `information_schema`.`Columns`.`DATA_TYPE`                AS `DATA_TYPE`,
                                   `information_schema`.`Columns`.`CHARACTER_MAXIMUM_LENGTH` AS `CHARACTER_MAXIMUM_LENGTH`,
                                   `information_schema`.`Columns`.`CHARACTER_OCTET_LENGTH`   AS `CHARACTER_OCTET_LENGTH`,
                                   `information_schema`.`Columns`.`NUMERIC_PRECISION`        AS `NUMERIC_PRECISION`,
                                   `information_schema`.`Columns`.`NUMERIC_SCALE`            AS `NUMERIC_SCALE`,
                                   `information_schema`.`Columns`.`DATETIME_PRECISION`       AS `DATETIME_PRECISION`,
                                   `information_schema`.`Columns`.`CHARACTER_SET_NAME`       AS `CHARACTER_SET_NAME`,
                                   `information_schema`.`Columns`.`COLLATION_NAME`           AS `COLLATION_NAME`,
                                   `information_schema`.`Columns`.`COLUMN_TYPE`              AS `COLUMN_TYPE`,
                                   `information_schema`.`Columns`.`COLUMN_KEY`               AS `COLUMN_KEY`,
                                   `information_schema`.`Columns`.`EXTRA`                    AS `EXTRA`,
                                   `information_schema`.`Columns`.`PRIVILEGES`               AS `PRIVILEGES`,
                                   `information_schema`.`Columns`.`COLUMN_COMMENT`           AS `COLUMN_COMMENT`
                            from `INFORMATION_SCHEMA`.`Columns`
                            where (`information_schema`.`Columns`.`TABLE_SCHEMA` = 'aliyun'));

