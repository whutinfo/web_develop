create procedure proc_get_column1(IN database_str varchar(100), IN table_str varchar(100), IN column_str varchar(100),
                                  OUT column_comment_str varchar(100))
BEGIN
     DECLARE comment_str VARCHAR(100);
	/*SELECT column_comment FROM INFORMATION_SCHEMA.Columns WHERE table_name='Goods_Table' AND table_schema='aliyun'  and column_name = 'goodsName' into column_comment_str;*/
     SELECT column_comment FROM INFORMATION_SCHEMA.Columns WHERE table_schema=database_str  AND table_name=table_str AND  column_name = column_comment_str INTO comment_str;
     SET column_comment_str = comment_str;
     SELECT column_comment_str ;
END;

