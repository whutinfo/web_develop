create procedure proc_get_column_demo1(IN pColumn varchar(100), OUT pRet varchar(100))
BEGIN
     declare tempstr VARCHAR(100);
     
     SELECT 
	goodsName 
     FROM
	aliyun.Goods_Table
     WHERE goodsName = pColumn
     INTO tempstr;
     set pRet=tempstr;
     SELECT @pRet;
END;

