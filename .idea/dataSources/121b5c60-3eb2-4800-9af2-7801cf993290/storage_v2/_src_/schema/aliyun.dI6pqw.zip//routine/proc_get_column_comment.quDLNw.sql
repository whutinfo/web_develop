create procedure proc_get_column_comment(IN database_str varchar(100), IN table_str varchar(100),
                                         IN column_str varchar(100), OUT column_comment_str varchar(100))
BEGIN
     SELECT column_comment FROM INFORMATION_SCHEMA.Columns WHERE table_schema=database_str  AND table_name=table_str AND  column_name=column_str INTO column_comment_str;
     SELECT column_comment_str;
    END;

